# AFECUT PRO

A Next.js web starter for cloud-powered transparent background removal.

## Important capability note

This first implementation connects to a general-purpose background-removal model (`bria/remove-background`) through Replicate. It can produce transparent cutouts, but **it does not yet perform the advanced relationship reasoning described in the product brief** (for example, reliably keeping a chair when someone is sitting on it while removing the same chair when it is merely nearby). The Keep/Remove context fields are currently collected by the interface but are not consumed by this model. Do not market this starter as having that capability until a semantic object-selection and mask-refinement stage is integrated and tested.

## Requirements

- Node.js 18+
- A Replicate API token
- Replicate account access and billing for the selected model

## Run locally

1. Install dependencies: `npm install`
2. Copy `.env.example` to `.env.local`
3. Add your token to `REPLICATE_API_TOKEN`
4. Run `npm run dev`
5. Open http://localhost:3000

The API token is only read by the server route. Never expose it in browser code or commit `.env.local`.

## Current behavior

- Image upload via picker or drag-and-drop
- 20 MB upload guard
- Cloud processing through Replicate
- Transparent PNG response and download
- Original upload is retained in the browser for comparison
- Export dimensions are determined by the provider model output; exact pixel-for-pixel preservation is not guaranteed

## Production hardening still required

- Add authentication, rate limits, abuse protection and upload quotas
- Add explicit image-retention/deletion policy and provider privacy review
- Validate actual model input/output contract against the selected Replicate model version
- Add semantic scene analysis and object relationship reasoning
- Add interactive keep/remove brush with mask editing, edge refinement and undo/redo
- Add alpha-edge quality checks, original-dimension validation and metadata/colour-profile handling
- Add tests for hair, fur, transparent objects, groups, mobility aids, furniture, shadows and occlusions
- Add a queue for large images and robust timeout/status handling
