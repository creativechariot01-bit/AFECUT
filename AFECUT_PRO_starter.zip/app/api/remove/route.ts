import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const maxDuration = 120;

export async function POST(req: NextRequest) {
  const token = process.env.REPLICATE_API_TOKEN;
  if (!token) return NextResponse.json({error:"Cloud processing is not configured. Add REPLICATE_API_TOKEN to .env.local and restart the server."},{status:503});

  try {
    const form = await req.formData();
    const image = form.get("image");
    if (!(image instanceof File)) return NextResponse.json({error:"Please upload an image."},{status:400});
    if (!image.type.startsWith("image/")) return NextResponse.json({error:"Unsupported file type."},{status:400});
    if (image.size > 20*1024*1024) return NextResponse.json({error:"Image exceeds the 20 MB limit."},{status:413});

    // Replicate receives the original image as a data URL. The API token stays server-side.
    const bytes = Buffer.from(await image.arrayBuffer());
    const dataUrl = `data:${image.type};base64,${bytes.toString("base64")}`;
    const model = process.env.REPLICATE_MODEL || "bria/remove-background";
    const start = await fetch(`https://api.replicate.com/v1/models/${model}/predictions`, {
      method:"POST",
      headers:{"Authorization":`Bearer ${token}`,"Content-Type":"application/json","Prefer":"wait=60"},
      body:JSON.stringify({input:{image:dataUrl}})
    });
    const prediction = await start.json();
    if (!start.ok) return NextResponse.json({error:prediction.detail || prediction.error || "The AI provider rejected the request."},{status:start.status});
    let output = prediction.output;
    if (prediction.status !== "succeeded" && prediction.urls?.get) {
      let current = prediction;
      for (let i=0;i<24 && !["succeeded","failed","canceled"].includes(current.status);i++) {
        await new Promise(r=>setTimeout(r,2500));
        const poll = await fetch(current.urls.get,{headers:{"Authorization":`Bearer ${token}`}});
        current = await poll.json();
      }
      if (current.status !== "succeeded") return NextResponse.json({error:current.error || "Processing timed out. Please try again."},{status:502});
      output = current.output;
    }
    const outputUrl = Array.isArray(output) ? output[0] : output;
    if (typeof outputUrl !== "string") return NextResponse.json({error:"The AI provider returned an unexpected result."},{status:502});
    const imageResponse = await fetch(outputUrl);
    if (!imageResponse.ok) return NextResponse.json({error:"Could not retrieve the processed image."},{status:502});
    const result = Buffer.from(await imageResponse.arrayBuffer());
    return new NextResponse(result,{headers:{
      "Content-Type":"image/png",
      "Content-Disposition":'attachment; filename="afecut-pro.png"',
      "Cache-Control":"no-store"
    }});
  } catch (err) {
    console.error("AFECUT PRO processing error",err);
    return NextResponse.json({error:"Unexpected processing error. Please try again."},{status:500});
  }
}
