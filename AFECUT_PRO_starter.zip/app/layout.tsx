import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "AFECUT PRO — Precision Background Studio",
  description: "Cloud-powered image background removal."
};
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}
