'use client';
import { useRef, useState } from 'react';

export default function Home() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [file,setFile] = useState<File|null>(null);
  const [source,setSource] = useState('');
  const [result,setResult] = useState('');
  const [busy,setBusy] = useState(false);
  const [error,setError] = useState('');
  const [keep,setKeep] = useState('');
  const [remove,setRemove] = useState('');
  const [quality,setQuality] = useState('original');
  const [drag,setDrag] = useState(false);

  function choose(f?:File) {
    if (!f) return;
    if (!f.type.startsWith('image/')) { setError('Please choose a valid image file.'); return; }
    if (f.size > 20*1024*1024) { setError('Maximum upload size is 20 MB for this starter build.'); return; }
    setFile(f); setSource(URL.createObjectURL(f)); setResult(''); setError('');
  }
  async function process() {
    if (!file) return;
    setBusy(true); setError(''); setResult('');
    try {
      const data = new FormData();
      data.append('image',file);
      data.append('keep',keep);
      data.append('remove',remove);
      data.append('quality',quality);
      const response = await fetch('/api/remove',{method:'POST',body:data});
      if (!response.ok) {
        const body = await response.json().catch(()=>({}));
        throw new Error(body.error || 'Background removal failed.');
      }
      const blob = await response.blob();
      setResult(URL.createObjectURL(blob));
    } catch(e:any) { setError(e.message || 'Something went wrong.'); }
    finally { setBusy(false); }
  }
  function download() {
    if (!result) return;
    const a=document.createElement('a'); a.href=result;
    const stem=(file?.name || 'image').replace(/\.[^.]+$/,'');
    a.download=stem+'-afecut-pro.png'; a.click();
  }
  return <main className="shell">
    <header className="top"><a className="brand" href="#"><span className="mark">A</span><span>AFE<span className="gold">CUT</span> PRO</span></a><span className="pill"><i/> CLOUD STUDIO</span></header>
    <section className="hero"><div className="eyebrow">INTELLIGENT IMAGE CUTOUT</div><h1>Keep what matters.<br/><em>Remove the rest.</em></h1><p>Clean, transparent cutouts powered by cloud AI. Upload an image to get started.</p></section>
    <section className="workspace">
      <div className="panel">
        <div className="panelhead"><div><b>01 / YOUR IMAGE</b><small>Upload JPG, PNG or WEBP</small></div><span className="muted">MAX 20 MB</span></div>
        <div className={'drop '+(drag?'drag':'')} onDragOver={e=>{e.preventDefault();setDrag(true)}} onDragLeave={()=>setDrag(false)} onDrop={e=>{e.preventDefault();setDrag(false);choose(e.dataTransfer.files?.[0])}} onClick={()=>inputRef.current?.click()}>
          <input ref={inputRef} type="file" accept="image/*" hidden onChange={e=>choose(e.target.files?.[0])}/>
          {source ? <img className="source" src={source} alt="Original upload"/> : <><div className="uploadicon">↥</div><b>Drop your image here</b><span>or <u>browse files</u></span><small>Portraits · Products · Objects · Pets</small></>}
        </div>
        {file && <div className="fileline"><span>{file.name}</span><span>{(file.size/1024/1024).toFixed(2)} MB</span><button className="link" onClick={()=>{setFile(null);setSource('');setResult('');}}>Remove</button></div>}
      </div>
      <div className="panel settings">
        <div className="panelhead"><div><b>02 / CUTOUT INTENT</b><small>Give the AI extra context</small></div><span className="step">OPTIONAL</span></div>
        <label>KEEP these objects <span>e.g. chair the person is sitting on, handbag being held</span></label>
        <textarea value={keep} onChange={e=>setKeep(e.target.value)} placeholder="Describe objects that must remain with the subject…"/>
        <label>REMOVE these objects <span>e.g. empty chair beside the person, wall decor</span></label>
        <textarea value={remove} onChange={e=>setRemove(e.target.value)} placeholder="Describe distracting objects to remove…"/>
        <div className="quality"><div><b>Export preference</b><small>PNG with transparent background</small></div><select value={quality} onChange={e=>setQuality(e.target.value)}><option value="original">Preserve dimensions</option><option value="standard">Standard</option></select></div>
        <button className="primary" disabled={!file||busy} onClick={process}>{busy?<><span className="spinner"/> Processing in cloud…</>:'Remove background  →'}</button>
        {error && <div className="error">{error}</div>}
        <p className="note">Your image is sent securely to the configured AI provider for processing. Do not upload sensitive images unless you are comfortable with that provider's terms.</p>
      </div>
    </section>
    <section className="output">
      <div className="outputhead"><div><b>03 / RESULT</b><small>Your transparent cutout appears here</small></div>{result&&<button className="download" onClick={download}>↓ Download PNG</button>}</div>
      <div className="preview">
        {result ? <img src={result} alt="Background removed result"/> : <div className="empty"><div className="checker">✦</div><b>Nothing here yet</b><span>Upload an image and run background removal.</span></div>}
      </div>
    </section>
    <footer><span>AFECUT PRO</span><span>PRECISION FIRST · BUILT FOR CREATORS</span></footer>
  </main>;
}
